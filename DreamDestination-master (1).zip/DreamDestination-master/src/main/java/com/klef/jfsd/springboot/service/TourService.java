package com.klef.jfsd.springboot.service;

import com.klef.jfsd.springboot.model.Tour;

public interface TourService {
	public Tour checktourlogin(String uname,String pwd);

}
